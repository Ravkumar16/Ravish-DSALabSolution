package com.greatLearning;

import java.util.ArrayList;
import java.util.List;

import javax.xml.soap.Node;

public class BinnarytreeLongestPath {
	
	static class Node{
		Node leftNode;
		Node rightNode;
		int nodeData;
		
	}
	public static void inOrder (Node node){
		if (node == null){
			return;
		}
		inOrder(node.leftNode);
		System.out.print("  "+node.nodeData);
		inOrder(node.rightNode);
	
	}
	static List<Node> findlogetpath(Node root){
		if (root==null){
			return new ArrayList<>();
					}
		List<Node> leftNode = findlogetpath(root.leftNode);
		List<Node> rightNode = findlogetpath(root.rightNode);
		if(rightNode.size()>leftNode.size()){
			rightNode.add(root);
		}else {leftNode.add(root);}
		
		return (rightNode.size()>leftNode.size()) ? rightNode : leftNode;
		
	}
	public static void main (String[] args){
		Node root = newNode(100);
		root.leftNode= newNode(20);
		root.rightNode=newNode(130);
		root.leftNode.leftNode = newNode(10);
		root.leftNode.rightNode = newNode(50);
		root.rightNode.leftNode = newNode(110);
		root.rightNode.rightNode = newNode(140);
		root.leftNode.leftNode.rightNode = newNode(5);
		System.out.println("Inorder Traversel");
		inOrder(root);
		List<Node> longestPath = findlogetpath(root);
		System.out.println("\nLongest Path from the Leaf  is ");
		for (Node node : longestPath){
			System.out.println(node.nodeData + "  ");
		}
		
	}

	private static Node newNode(int i) {
		Node temp = new Node();
		temp.nodeData=i;
		temp.rightNode =null;
		temp.leftNode =null;
		return temp;
	}

}
