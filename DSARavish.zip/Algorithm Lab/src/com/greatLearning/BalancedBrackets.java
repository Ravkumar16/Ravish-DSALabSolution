package com.greatLearning;

import java.util.Scanner;
import java.util.Stack;

public class BalancedBrackets {
public static boolean isBalanced(String brackets){
	int len = brackets.length();
	
	if (len<=0||len %2 !=0){
		return false;
	}
	
	Stack<Character> stack = new Stack<Character>();
	
	for (int i= 0; i<len; i++){
		char currentChar = brackets.charAt(i);
		if (currentChar== '[' ||currentChar== '(' || currentChar== '{'){
			stack.push(currentChar);
		}else if (!stack.isEmpty()){
			if (currentChar== ']' ||currentChar== ')' || currentChar== '}'){
				char top = stack.peek();
				boolean isparenthesis = top == '(' && currentChar==')';
				boolean iscurly = top == '{' && currentChar=='}';
				boolean isSquare = top == '[' && currentChar==']';
				if (isparenthesis||iscurly||isSquare){
					stack.pop();
				}else { return false;}
			}else { return false;}
		}
	}
	return stack.isEmpty(); 	
}
 	public static void main (String[] args){
 		
 		Scanner sc= new Scanner(System.in); //System.in is a standard input stream.
 		System.out.print("Enter brackets: ");
 		String str= sc.nextLine();
 		
 		System.out.println("is it Balanced    " +isBalanced(str));
	
 	}
}
